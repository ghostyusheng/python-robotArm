import React, { Component } from 'react';
import { render } from 'react-dom';
import { Modal, Row, Col } from 'antd';
import { Form, Icon, Input, Button } from 'antd';

import axios from 'axios';



export default class York extends Component {
    state = { gold:0, log:'...', money: 0, visible: false };

      componentDidMount() {
            const that = this
            axios.get('/get')
            .then(function (response) {
                console.log(response.data.data)
                const data = response.data.data
                const arr = data.log.split("|");
                let msg = "";
                for (let k in arr) {
                    let v = arr[k];
                    msg += v + " <br>";
                }
                that.setState({
                    gold: data.gold,
                    money: data.money,
                    log: msg,
                });
            })
            .catch(function (error) {
                console.log(error);
            })
            .finally(function () {
            });
      }

    showModal = () => {
        this.setState({
          visible: true,
        });

    };

    handleOk = e => {
        console.log(e);
        this.setState({
          visible: false,
        });
    };

    handleCancel = e => {
        console.log(e);
        this.setState({
          visible: false,
        });
    };

    render() {
        console.log(123)
        return (
            <div>
                <div class="main-header">
                    <div class="content">
                      <h1 data-text="Robots">
                        Robots
                      </h1>
                      <h1 data-text="yu sheng">
                        yu sheng
                      </h1>
                    </div>
                    <img src="logo.png" alt="god in heart" height="100" />
                </div>
              <div className="gutter">
                <Row gutter={16} type="flex" justify="space-around" align="middle">
                  <Col className="gutter-row" span={6}>
                    <div className="gutter-box">
                        <img src="eva.jpg" /> 
                    </div>
                  </Col>
                  <Col className="gutter-row" span={6}>
                    <div className="gutter-box">
                        <img src="gold.jpg" />     
                    </div>
                  </Col>
                  <Col className="gutter-row" span={6}>
                    <div className="gutter-box">
                        <img src="money.jpg" />     
                    </div>
                  </Col>
                </Row>
                <Row gutter={[{ xs: 8, sm: 16, md: 24, lg: 32 }, 20]} type="flex" justify="space-around" align="middle">
                  <Col className="gutter-row" span={6}>
                    <div className="gutter-box">
                        <Button type="primary" onClick={this.showModal}>
                          Show EVA Log
                        </Button>
                        <Modal
                          title="detail"
                          visible={this.state.visible}
                          onOk={this.handleOk}
                          onCancel={this.handleCancel}
                        >
                          <p dangerouslySetInnerHTML={{__html: this.state.log}} ></p>
                        </Modal>
                    </div>
                  </Col>
                  <Col className="gutter-row" span={6}>
                    <div className="gutter-box">{this.state.gold}g (1x1x1cm/19.32g)</div>
                  </Col>
                  <Col className="gutter-row" span={6}>
                    <div className="gutter-box">{this.state.money}$ (1g/54$)</div>
                  </Col>
                </Row>
              </div>
            </div>
        );
    }
}
