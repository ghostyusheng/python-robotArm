from driver.core import CoreDriver


class SettingMiddleware:
    def __init__():
        self.core = Core()
        print('load core')
