# -*- coding:utf-8 -*-
import sys
import redshift_connector
from cron.base import Base
from function.function import config
from core.const import const
from core.core import CoreDriver
from kafka import KafkaConsumer
from time import time
from json import loads, dumps
from utils.utils import seconds_todate, seconds_tohour
from service.log import LogService


class RedshiftConsumer(Base):
    """消费来自kafka的日志数据,第一个参数传topic"""

    def init(self):
        r = "redshift"
        self.red = redshift_connector.connect(
             host=config(r, "host"),
             database='pf_gameplus',
             user=config(r, 'user'),
             password=config(r, 'password')
        )
        self.red.autocommit = True
        print('reconnect ok!')


    def execute(self,sql, _len):
        self.init()
        cursor = self.red.cursor()
        cursor.execute(sql)
        print(f'==> bulk write {_len} done!')


    def bulkWrite(self, lst):
        LEN = len(lst)
        print(f'==> bulk write {LEN}')
        head = "insert into ods.log(s,a,t,ip,delay,cid,uid,position,referer,ts,ext,dt,hour) values"
        values = []
        for i in lst:
                M = loads(str(i.value, 'utf-8'))
                s = M['s']
                a = M['a']
                t = M['t']
                ip = M['ip']
                delay = M.get('delay', 0)
                cid = M['cid']
                uid = M['uid']
                position = M['position']
                referer = M['referer']
                ts = M['ts']
                ext = dumps(M['ext'])
                dt = seconds_todate(ts)
                hour = int(seconds_tohour(ts))
                values.append(f"('{s}','{a}','{t}','{ip}',{delay},'{cid}','{uid}','{position}','{referer}',{ts},json_parse('{ext}'),'{dt}',{hour})")
        sql = head + ','.join(values)
        try:
            self.execute(sql, LEN)
        except Exception as ex:
            print(ex)        
            LogService.instance().user(f"cid:{cid},uid:{uid}").setLogName(
                'exception').addFileHandler().exception(ex)


    def _run(self, params=[]):
        from signal import signal, SIGPIPE, SIG_DFL
        signal(SIGPIPE,SIG_DFL)

        self.init()
        print("ENV:", const.ENV)
        if len(params) == 0:
            print('参数不够: eg: .py topic consumer_group')
            return
        consumer_group = topic = 'bigdata_' + params[0]
        BULK_SIZE = 50;
        if len(params) == 2:
            consumer_group = 'bigdata_' + params[1] 
        if len(params) == 3:
            BULK_SIZE = params[2]
        server = config('kafka', 'log').split(',')
        consumer = KafkaConsumer(topic, group_id=consumer_group, bootstrap_servers=server)
        print(f"==> SERVER: {server}")
        print(f"==> TOPIC: [{topic}],GROUP:[{consumer_group}] starting...")
        lst = []
        last_time = None
        TIME_SLOT = 3
        for message in consumer:
            lst.append(message) 
            ts = int(time())
            if len(lst) > 50 or ts % TIME_SLOT == 0:
                if not last_time:
                    last_time = ts
                if ts == last_time:
                    continue
                self.bulkWrite(lst)
                last_time = ts
                lst = []
