# -*- coding:utf-8 -*-
import sys
import re
import redshift_connector
from cron.base import Base
from function.function import config
from core.const import const
from core.core import CoreDriver
from kafka import KafkaConsumer
from time import time
from json import loads, dumps
from utils.utils import seconds_todate, seconds_tohour
from service.log import LogService
from time import time


class AzuraConsumer(Base):
    """消费来自azura adjust的回调日志数据"""

    def init(self):
        r = "redshift"
        self.red = redshift_connector.connect(
             host=config(r, "host"),
             database="gamedb_xzj",
             user=config(r, 'user'),
             password=config(r, 'password')
        )
        self.red.autocommit = True
        print('reconnect ok!')


    def execute(self,sql, _len):
        self.init()
        cursor = self.red.cursor()
        cursor.execute(sql)
        print(f'==> bulk write {_len} done!')


    def bulkWrite(self, lst):
        LEN = len(lst)
        print(f'==> bulk write {LEN}')
        head = 'insert into ods.azura_adjust("activity_kind","adgroup_name","adid","api_level","app_id","app_name","app_name_dashboard","app_version_raw","campaign_name","city","connection_type","country","creative_name","custom_timezone","device_manufacturer","device_name","device_type","environment","hardware_name","installed_at","ip_address","isp","language","lifetime_session_count","mixed_dev_id","network_name","network_type","os_name","os_version","postal_code","random","random_user_id","region","timestamp","timezone","tracker","tracker_name","tracking_enabled","server_id","uid", "_json","ts","dt","hour") values'
        values = []
        pattern = re.compile('\"properties\":(.|\n)*}\",')
        for i in lst:
                _json = str(i.value, 'utf-8')
                _json = re.sub(pattern, '', _json)
                M = loads(_json)
                activity_kind = M.get("activity_kind", '')
                adgroup_name = M.get("adgroup_name", '')
                adid = M.get("adid", '')
                api_level = M.get("api_level", '')
                app_id = M.get("app_id", '')
                app_name = M.get("app_name", '')
                app_name_dashboard = M.get("app_name_dashboard", '')
                app_version_raw = M.get("app_version_raw", '')
                campaign_name = M.get("campaign_name", '')
                city = M.get("city", '')
                connection_type = M.get("connection_type", '')
                country = M.get("country", '')
                creative_name = M.get("creative_name", '')
                custom_timezone = M.get("custom_timezone", '')
                device_manufacturer = M.get("device_manufacturer", '')
                device_name = M.get("device_name", '')
                device_type = M.get("device_type", '')
                environment = M.get("environment", '')
                hardware_name = M.get("hardware_name", '')
                installed_at = M.get("installed_at", '')
                ip_address = M.get("ip_address", '')
                isp = M.get("isp", '')
                language = M.get("language", '')
                lifetime_session_count = M.get("lifetime_session_count", '')
                mixed_dev_id = M.get("mixed_dev_id", '')
                network_name = M.get("network_name", '')
                network_type = M.get("network_type", '')
                os_name = M.get("os_name", '')
                os_version = M.get("os_version", '')
                postal_code = M.get("postal_code", '')
                random = M.get("random", '')
                random_user_id = M.get("random_user_id", '')
                region = M.get("region", '')
                timestamp = M.get("timestamp", '')
                timezone = M.get("timezone", '')
                tracker = M.get("tracker", '')
                tracker_name = M.get("tracker_name", '')
                tracking_enabled = M.get("tracking_enabled", '')
                server_id = M.get("serverid", '')
                uid = M.get("uid", '')
                ts = int(time())
                dt = seconds_todate(int(ts))
                hour = int(seconds_tohour(ts))
                values.append(f"('{activity_kind}','{adgroup_name}','{adid}','{api_level}','{app_id}','{app_name}','{app_name_dashboard}','{app_version_raw}','{campaign_name}','{city}','{connection_type}','{country}','{creative_name}','{custom_timezone}','{device_manufacturer}','{device_name}','{device_type}','{environment}','{hardware_name}','{installed_at}','{ip_address}','{isp}','{language}','{lifetime_session_count}','{mixed_dev_id}','{network_name}','{network_type}','{os_name}','{os_version}','{postal_code}','{random}','{random_user_id}','{region}','{timestamp}','{timezone}','{tracker}','{tracker_name}','{tracking_enabled}','{server_id}','{uid}','{_json}',{ts},'{dt}',{hour})")
        sql = head + ','.join(values)
        try:
            self.execute(sql, LEN)
        except Exception as ex:
            print(ex)        
            LogService.instance().user(f"adid:{adid}").setLogName(
                'exception').addFileHandler().exception(ex)


    def _run(self, params=[]):
        from signal import signal, SIGPIPE, SIG_DFL
        signal(SIGPIPE,SIG_DFL)

        self.init()
        consumer_group = topic = 'bigdata_azura_adjust'
        server = config('kafka', 'log').split(',')
        consumer = KafkaConsumer(topic, group_id=consumer_group, bootstrap_servers=server)
        print(f"==> SERVER: {server}")
        print(f"==> TOPIC: [{topic}],GROUP:[{consumer_group}] starting...")
        lst = []
        last_time = None
        TIME_SLOT = 3
        for message in consumer:
            lst.append(message) 
            ts = int(time())
            if len(lst) > 2000 or ts % TIME_SLOT == 0:
                if not last_time:
                    last_time = ts
                if ts == last_time:
                    continue
                self.bulkWrite(lst)
                last_time = ts
                lst = []
