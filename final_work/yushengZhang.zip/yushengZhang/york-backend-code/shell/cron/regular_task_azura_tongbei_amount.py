# -*- coding:utf-8 -*-
import sys
import redshift_connector
from cron.base import Base
from function.function import config
from core.const import const
from core.core import CoreDriver
from kafka import KafkaConsumer
from time import time
from json import loads, dumps
from utils.utils import seconds_todate, seconds_tohour
from service.log import LogService
from time import time


class RegularTaskAzuraTongbeiAmount(Base):
    """azura铜贝每日统计"""

    def init(self):
        r = "redshift"
        self.red = redshift_connector.connect(
             host=config(r, "host"),
             database="gamedb_xzj",
             user=config(r, 'user'),
             password=config(r, 'password')
        )
        self.red.autocommit = True
        print('reconnect ok!')


    def execute(self,sql):
        self.init()
        cursor = self.red.cursor()
        cursor.execute(sql)
        print(f'==> write done!')


    def _run(self, params=[]):
        sql = """
            insert into azura_tongbei_groupby_dt(dt, amount) values(CURRENT_DATE, (select amount from (
        with m as
            (
            select
            vopenid,
            gamesvrid,
            to_date(dateadd(hour, +5, dteventtime),'yyyy-mm-dd') as dt,
            '缘物' as output_type,
            max(RIGHT(Attach,CHARINDEX(',10000003', (REVERSE(Attach)))-1)::int) as iMoney
            from
                (
                select
                vopenid,
                gamesvrid,
                dteventtime,
                json_extract_path_text(_json, 'Attach')::varchar as Attach from gamedb_xzj.ods.gamelog_sls_rt_0104
                where name = 'PlayerMail'
                and json_extract_path_text(_json, 'MailId') = 37950021
                and gamesvrid in (select gamesvrid from gamedb_xzj."ods"."server_info" where open_to_user = 'yes')
                and dteventtime >='2023-01-05 10:00:00'        --dteventtime为服务器时间
                and Attach like '%30000001%'
                )
            group by vopenid,gamesvrid,dt
            )
        , w as
            (
            select
            vopenid,
            gamesvrid,
            to_date(dateadd(hour, +5, dteventtime),'yyyy-mm-dd') as dt,
            '万盟争霸' as output_type,
            max(SUBSTRING(Attach,LEN(LEFT(Attach,CHARINDEX('30000001,', Attach)+9)),LEN(Attach) - LEN(LEFT(Attach,CHARINDEX('30000001,', Attach))) - LEN(RIGHT(Attach,CHARINDEX('08000003;', (REVERSE(Attach)))+16)))::int) as iMoney
            from
                (
                select
                vopenid,
                gamesvrid,
                dteventtime,
                json_extract_path_text(_json, 'Attach')::varchar as Attach from gamedb_xzj.ods.gamelog_sls_rt_0104
                where name = 'PlayerMail'
                and json_extract_path_text(_json, 'MailId') in
                    (
                    37001217
                    ,37001218
                    ,37001219
                    ,37001220
                    ,37001221
                    ,37001222
                    ,37001223
                    ,37001208
                    ,37001209
                    ,37001210
                    ,37001211
                    ,37001225
                    )
                and attach like '%30000001,%'
                and gamesvrid in (select gamesvrid from gamedb_xzj."ods"."server_info" where open_to_user = 'yes')
                and dteventtime >='2023-01-05 10:00:00'        --dteventtime为服务器时间
                )
            group by vopenid,gamesvrid,dt
            )
        , extra as
            (
            select
            vopenid,
            gamesvrid,
            to_date(dateadd(hour, +5, dteventtime),'yyyy-mm-dd') as dt,
            case
                when reason in (128,129) then '神龙盘'
                when reason = 65  then '帮会盗贼'
                when reason in (125,126) then '比武大会'
                when reason = 35  then '活跃度达成奖励'
                when reason = 2  then '27级对话'
            end as output_type,
            json_extract_path_text(_json, 'iMoney')::int as iMoney
            from gamedb_xzj.ods.gamelog_sls_rt_0104
            where name = 'MoneyFlow' and json_extract_path_text(_json, 'iMoneyType') = 0
            and gamesvrid in (select gamesvrid from gamedb_xzj."ods"."server_info" where open_to_user = 'yes')
            and dteventtime >='2023-01-05 10:00:00'        --dteventtime为服务器时间
            and reason in (128,129,65,125,126,35,2)
            )
        , extra1 as
            (
            select
            vopenid,
            gamesvrid,
            to_date(dateadd(hour, +5, dteventtime),'yyyy-mm-dd') as dt,
            case
                when detail like '%30001412%' then '帮会联赛奖励宝箱'
                when detail like '%30090032%' then '高级煞魂宝箱'
            end as output_type,
            case
                when json_extract_path_text(_json, 'iMoney') ~ '^[0-9]+$' then json_extract_path_text(_json, 'iMoney')::int
                else null
            end as iMoney
            from gamedb_xzj.ods.gamelog_sls_rt_0104
            where name = 'MoneyFlow' and json_extract_path_text(_json, 'iMoneyType') = 0
            and gamesvrid in (select gamesvrid from gamedb_xzj."ods"."server_info" where open_to_user = 'yes')
            and dteventtime >='2023-01-05 10:00:00'        --dteventtime为服务器时间
            and (detail like '%30001412%' or detail like '%30090032%')
            )

        select sum(iMoney) as amount from
        (
        select * from m
        union all
        select * from w
        union all
        select * from extra
        union all
        select * from extra1
        )
    )))
        """
        try:
            self.execute(sql)
            print('finish')
        except Exception as ex:
            print(ex)        
            LogService.instance().user(f"").setLogName('exception').addFileHandler().exception(ex)
