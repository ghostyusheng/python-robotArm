from core.alice.component.component import Component

class UtilComponent(Component):

    def setStrategiesCount(self, ct: int):
        self.strategies_count = ct
