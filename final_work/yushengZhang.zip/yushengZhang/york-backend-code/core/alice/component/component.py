class Component:
    pass
