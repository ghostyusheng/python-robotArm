from core.alice.strategy.strategy import Strategy

class HierarchyStrategy(Strategy):
    pass
