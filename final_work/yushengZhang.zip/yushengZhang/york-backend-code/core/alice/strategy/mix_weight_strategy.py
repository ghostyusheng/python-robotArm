from core.alice.strategy.strategy import Strategy

class MixWeightStrategy(Strategy):
    pass
