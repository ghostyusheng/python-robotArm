from uuid import uuid1


class RequestEntity:
    GET = {}
    POST = {}
    _method = "GET"

    def __repr__(self):
        return str(self.GET) + str(self.POST)

    def __init__(self, get_arguments={}, post_arguments={}):
        class _Obj:
            def __getitem__(self, attr):
                return getattr(self, attr, None)

            def __str__(self):
                return '&'.join(['%s:%s' % item for item in self.__dict__.items()])

        _get = _Obj()
        _post = _Obj()
        for k, v in get_arguments.items():
            key = k
            setattr(_get, key, str(v[0], encoding="utf-8"))
        for k, v in post_arguments.items():
            key = k
            setattr(_post, key, str(v[0], encoding="utf-8"))
        self.GET = _get
        self.POST = _post

    def method(self, method):
        self._method = method
        return self

    def _set(self, old, new):
        _obj = getattr(self, self._method)
        setattr(_obj, old, new)

    def _get(self, key):
        _obj = getattr(self, self._method)
        return getattr(_obj, key, None)

    def setKeyword(self, new):
        self._set("keyword", new)
        return self

    def setFrom(self, new):
        self._set("from", new)
        return self

    def setLimit(self, new):
        self._set("limit", new)
        return self

    def setHighlight(self, new):
        self._set("highlight", new)
        return self

    def setHighlightSecret(self, new):
        self._set("highlight_secret", new)
        return self

    def setSort(self, new):
        self._set("sort", new)
        return self

    def setAttr(self, new):
        self._set("attr", new)
        return self

    def setUserId(self, new):
        self._set("user_id", new)
        return self

    def setDeviceId(self, new):
        self._set("device_id", new)
        return self

    def setPlatform(self, new):
        self._set("platform", new)
        return self

    def setStore(self, new):
        self._set("store", new)
        return self

    def setForumId(self, new):
        self._set("forum_id", new)
        return self

    def setForumType(self, new):
        self._set("forum_type", new)
        return self

    def setSessionId(self, new=None):
        if not new:
            new = str(uuid1())
        self._set("session_id", new)
        return self

    def setCorrectType(self, new):
        self._set("correct_type", new)
        return self

    def setType(self, new):
        self._set("type", new)
        return self

    def setWithIntro(self, new):
        self._set("with_intro", new)

    def setWithRecommendedTitle(self, new):
        self._set("with_recommended_title", new)

    def setWithAppTitle(self, new):
        self._set("with_app_title", new)

    def setAppId(self, new):
        self._set("app_id", new)

    def setId(self, new):
        self._set("id", new)

    def setTitleOnly(self, new):
        self._set("title_only", new)

    def setScene(self, new):
        self._set("scene", new)

    def setIndex(self, new):
        self._set("index", new)

    def setAlias(self, new):
        self._set("alias", new)

    def setArea(self, new):
        self._set("area", new)
    def setVideoId(self,new):
        self._set("video_id",new)
    def getArea(self):
        return self._get("area")

    def setDate(self, new):
        self._set("date", new)
    def getDate(self):
        return self._get("date")

    def getKeyword(self):
        return self._get("keyword")

    def setChannelAppId(self,new):
        self._set("channel_app_id",new)
    def getChannelAppId(self):
        return self._get("channel_app_id")

    def setVersion(self,new):
        self._set("version",new)
    def getVersion(self):
        return self._get("version")

    def setTmpParam(self,new):
        self._set("tmp_param", new)

    def getTmpParam(self):
        return int(self._get("tmp_param"))

    def setLang(self,new):
        self._set("lang", new)

    def getLang(self):
        return self._get("lang")

    def setContentType(self,new):
        self._set("content_type", new)

    def getContentType(self):
        return self._get("content_type")

    def setReload(self,new):
        self._set("reload", new)

    def getReload(self):
        return self._get("reload")

    def getCollectionId(self):
        return self._get("collectionIdList")


    def getNftType(self):
        return self._get("nftType")

    def getNftTypeList(self):
        return self._get("nftTypeList")

    def setAction(self,new):
        self._set("action", new)

    def setLabelIdList(self, new):
        return self._set("labelIdList", new)

    def setPriceLow(self, new):
        return self._set("priceLow", new)

    def setPriceHigh(self, new):
        return self._set("priceHigh", new)

    def setCollectionId(self, new):
        return self._set("collectionIdList", new)

    def setIsTop(self,new):
        self._set("is_top", new)

    def setTs(self,new):
        self._set("ts", new)

    def setGameId(self,new):
        self._set("gameId", new)

    def setNftType(self,new):
        self._set("nftType", new)

    def setNftTypeList(self,new):
        self._set("nftTypeList", new)

    def setDtRange(self,new):
        self._set("dtRange", new)

    def setChainId(self,new):
        self._set("chainId", new)

    def setFlat(self,new):
        self._set("flat", new)

    def setLog(self,new):
        self._set("log", new)

    def getAction(self):
        return self._get("action")
        

    def getIsTop(self):
        return self._get("is_top")

    def getFrom(self):
        return self._get("from")

    def getLimit(self):
        return self._get("limit")

    def getHighlight(self):
        return self._get("highlight")

    def getHighlightSecret(self):
        return self._get("highlight_secret")

    def getAttr(self):
        return self._get("attr")

    def getSort(self):
        sort = self._get("sort")
        lst = []
        slices = sort.split('|')
        if len(slices) > 0:
            for _field in slices:
                if _field:
                    k, v = _field.split(',')
                    lst.append({ k: v})
                return lst
        else:
            return []

    def getUserId(self):
        return self._get("user_id")

    def getDeviceId(self):
        return self._get("device_id")

    def getPlatform(self):
        return self._get("platform")

    def getStore(self):
        return self._get("store")

    def getForumId(self):
        return self._get("forum_id")

    def getForumType(self):
        return self._get("forum_type")

    def getSessionId(self):
        return self._get("session_id")

    def getCorrection(self):
        return self._get("need_correct")

    def getType(self):
        return self._get("type")

    def getWithIntro(self):
        return self._get("with_intro")

    def getWithRecommendedTitle(self):
        return self._get("with_recommended_title")

    def getWithAppTitle(self):
        return self._get("with_app_title")

    def getAppId(self):
        return self._get("app_id")

    def getId(self):
        return self._get("id")

    def getTitleOnly(self):
        return self._get("title_only")

    def getScene(self):
        return self._get("scene")

    def getCorrectType(self):
        return self._get("correct_type")

    def getIndex(self):
        return self._get("index")

    def getAlias(self):
        return self._get("alias")

    def getVideoId(self):
        return self._get("video_id")

    def getLabelIdList(self):
        return self._get("labelIdList")

    def getPriceLow(self):
        return self._get("priceLow") if self._get("priceLow") else None

    def getPriceHigh(self):
        return self._get("priceHigh")  if self._get("priceHigh") else None

    def getTs(self):
        return self._get("ts")

    def getGameId(self):
        return self._get("gameId")

    def getDtRange(self):
        return self._get("dtRange")

    def getChainId(self):
        return self._get("chainId")

    def getFlat(self):
        return self._get("flat")

    def getLog(self):
        return self._get("log")
