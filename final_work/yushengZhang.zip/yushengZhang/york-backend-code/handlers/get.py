import copy
import json
import mysql.connector

from tornado.web import MissingArgumentError
from core.entity.request import RequestEntity
from core.httpcode import HTTPCode
from function.function import R
from handlers.base import BaseHandler
from middleware.request import RequestMiddleware
from utils import utils
from utils.utils import log_exception, syslog

class GetHandler(BaseHandler):
    async def get(self):
        config = {
          'user': 'root',
          'password': 'root',
          'host': '127.0.0.1',
          'database': 'york',
          'raise_on_warnings': True
        }

        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()
        sql = ("select * from eva")
        cursor.execute(sql)
        res = [i for i in cursor]
        gold = res
        res = [i[2].strftime("%m/%d/%Y, %H:%M:%S") + " ===> " + i[1] for i in res]
        gold = round(sum([json.loads(i[1])['perimeter'] for i in gold]) * 19, 0)
        money = round(gold * 64, 0)
        cnx.commit()
        cursor.close()
        cnx.close()

        self.out({
            'gold': gold,
            'money': money,
            'log': '|'.join(res)
        })
