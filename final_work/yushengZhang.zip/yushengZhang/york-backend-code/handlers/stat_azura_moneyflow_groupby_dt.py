# -*- coding: utf-8 -*-
from middleware.request import RequestMiddleware
from core.entity.request import RequestEntity
from function.function import R
from handlers.base import BaseHandler
from service.stat import StatService

class AzuraMoneyflowGroupbyDt(BaseHandler):

    async def get(self, request=None):
        if not request:
            request: RequestEntity = R()
        result = await StatService.instance().azuraMoneyflowGroupbyDt(request)
        self.out(result)


    async def post(self):
        dts = self.get_json_argument("dtRange", "")
        request: RequestEntity = R()
        request.setDtRange(dts)
        return await self.get(request)
