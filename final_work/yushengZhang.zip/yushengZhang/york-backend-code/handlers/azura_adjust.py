# -*- coding: utf-8 -*-
import json
from handlers.base import BaseHandler
from core.const import const
from share.repository.kafka import KafkaRepository
from utils.keygen import Keygen

class AzuraAdjustHandler(BaseHandler):

    async def get(self):
        channel = self.get_query_argument("_channel","")
        msg = self.request.arguments.values()
        tk = self.get_query_argument("_tk","")

        if not channel in ('test', 'log', 'azura_adjust'):
            self.out(code=500, msg="c fail")
            return

        if tk != 'tks12dnf1':
            self.out(code=500, msg="tk fail")
            return

        M = {}
        for i, j in  self.request.arguments.items():
            if i in ('_channel', '_tk'):
                continue
            M[i] = j[0].decode('utf-8')

        KafkaRepository.instance().send(channel, M)
        
        self.out(code=200)
