import copy

from tornado.web import MissingArgumentError
from core.entity.request import RequestEntity
from core.httpcode import HTTPCode
from function.function import R
from handlers.base import BaseHandler
from middleware.request import RequestMiddleware
from utils import utils
from utils.utils import log_exception, syslog

import mysql.connector


class PutHandler(BaseHandler):
    async def post(self):
        RequestMiddleware.verifyParams([
            ["log", '']
        ])


        request: RequestEntity = R()
        log = request.getLog()
        if not log:
            self.out(code=9999)
            return

        config = {
          'user': 'root',
          'password': 'root',
          'host': '127.0.0.1',
          'database': 'york',
          'raise_on_warnings': True
        }

        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()
        sql = ("INSERT INTO eva (log) VALUES ('%s')" % log)
        cursor.execute(sql)
        cnx.commit()
        cursor.close()
        cnx.close()

        print('log =====>', log)
        self.out()

