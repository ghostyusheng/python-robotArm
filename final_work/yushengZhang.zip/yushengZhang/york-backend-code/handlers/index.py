import copy

from tornado.web import MissingArgumentError
from core.entity.request import RequestEntity
from core.httpcode import HTTPCode
from function.function import R
from handlers.base import BaseHandler
from middleware.request import RequestMiddleware
from utils import utils
from utils.utils import log_exception, syslog

class IndexHandler(BaseHandler):
    async def get(self):
        self.render('../york-frontend/build/index.html')
