# -*- coding: utf-8 -*-
from middleware.request import RequestMiddleware
from core.entity.request import RequestEntity
from function.function import R
from handlers.base import BaseHandler
from service.stat import StatService

class StatGroupbyNftCollectionLabelHandler(BaseHandler):

    async def get(self, request=None):
        if not request:
            RequestMiddleware.verifyParams([
                ['gameId', '', 'str'],
                ['labelId', '', 'str'],
                ['collectionId', '', 'str'],
                ['nftType', '', 'str'],
            ])
            request: RequestEntity = R()
        result = await StatService.instance().groupby_nft_collection_label(request)
        self.out(result)


    async def post(self):
        collectionId = self.get_json_argument("collectionId", "")
        nftType = self.get_json_argument("nftType", "")
        labelId = self.get_json_argument("labelId", "")
        gameId = self.get_json_argument("gameId", "")
        request: RequestEntity = R()
        request.setCollectionId(collectionId)
        request.setLabelIdList(labelId)
        request.setNftType(nftType)
        request.setGameId(gameId)
        return await self.get(request)
