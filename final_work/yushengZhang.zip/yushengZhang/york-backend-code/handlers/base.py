import tornado
import time
from tornado.escape import json_decode, to_unicode
from tornado.web import RequestHandler

from core.entity.request import RequestEntity
from core.entity.sdebug import SdebugEntity
from core.http import HTTP
from function.context import RequestContext
from utils.redis_key_tool import *
from utils.utils import log_exception,syslog


allow_origins = [
    "https://www.yeehagames.com",
    "https://yeehagames.com",
    "http://localhost:3000",
    "https://gameplus-web.qa.davionlabs.com",
    "https://gameplus-web.staging.davionlabs.com",
]


class BaseHandler(RequestHandler):
    def set_default_headers(self):
        origin = self.request.headers.get("Origin")
        if origin in allow_origins:
            self.set_header('Access-Control-Allow-Origin', origin)
            self.set_header('Access-Control-Allow-Headers', '*')
            self.set_header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
            self.set_header('Access-Control-Max-Age', 1728000)


    def options(self, *args):
        self.set_status(204)
        self.finish()


    def initialize(self):
        arguments = self.request.arguments
        ctx = RequestContext()
        http_message = \
            ' '.join([k + "|" + str(v[0], encoding="utf-8") for k, v in arguments.items()]) + \
            ' '.join([k + "|" + str(v[0], encoding="utf-8")
                      for k, v in self.request.body_arguments.items()])
        http_message += self.request.body.decode('utf-8')
        ctx.HTTP_MESSAGE = http_message

        if 'SDEBUG' in arguments.items():
            if self.get_argument('SDEBUG') == '1':
                ctx.SEARCH_DEBUG = True
        else:
            ctx.SEARCH_DEBUG = self.get_argument('SDEBUG', False)
        ctx.HANDER = self
        ctx._REQUEST = RequestEntity(arguments, self.request.body_arguments)
        ctx._SDEBUG = SdebugEntity()
        ctx.HTTP_START_TS = time.time()
        context_var.set(ctx)
        if self.request.uri != '/_health':
            syslog(http_message)

    def out(self, *args, **kwargs):
        HTTP(self).out(*args, **kwargs)

    def debug(self, what):
        context_var.get().HANDER.finish(what)

    def get_json_argument(self, name, default=None):
        args = json_decode(self.request.body)
        name = to_unicode(name)
        if name in args:
            return args[name]
        elif default is not None:
            return default
        else:
            raise tornado.web.MissingArgumentError(name)

    def write_error(self, status_code, **kwargs):
        msg = str(kwargs.get('exc_info')[1])
        log_exception(Exception("[uncatched exception]: " + msg))
        self.out(msg=msg, httpcode=status_code)
