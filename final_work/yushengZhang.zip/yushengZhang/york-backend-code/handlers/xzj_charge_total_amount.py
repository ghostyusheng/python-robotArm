# -*- coding: utf-8 -*-
from middleware.request import RequestMiddleware
from core.entity.request import RequestEntity
from function.function import R
from handlers.base import BaseHandler
from service.stat import StatService

class XzjChargeTotalAmount(BaseHandler):

    async def get(self, request=None):
        result = await StatService.instance().xzj_charge_total_amount(request)
        self.out(result)


    async def post(self):
        request: RequestEntity = R()
        return await self.get(request)
