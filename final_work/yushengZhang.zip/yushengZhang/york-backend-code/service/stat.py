# -*- coding:utf-8 -*-
import numpy as np
import redshift_connector
from core.decorator.cache import Cache
from core.entity.request import RequestEntity
from function.function import config, SDEBUG, DEBUG
from service.base import BaseService
from service.cache import CacheService
from utils.utils import log_exception, index_exception, eslog
from core.const import const
from repository.db import DBRepository

class StatService(BaseService):

    def __init__(self):
        pass

    @Cache.set(cache_time=60*5)
    async def groupby_nft_collection_label(self, request: RequestEntity):
        if not (request.getGameId() or request.getLabelIdList() or request.getCollectionId() or request.getNftType()):
            return -1

        statements = []
        if request.getGameId():
            statements.append(f"game_id in ({request.getGameId()})")
        if request.getLabelIdList():
            statements.append(f"label_id in ({request.getLabelIdList()})")
        if request.getCollectionId():
            statements.append(f"collection_id in ({request.getCollectionId()})")
        if request.getNftType():
            statements.append(f"nft_type in ({request.getNftType()})")
        statements = " and ".join(statements)

        sql = f"""
            SELECT
                label_id::varchar, collection_id, nft_type, cnt
            FROM
                "market"."stat_groupby_nft_collection_type_label" 
            where
                {statements}
        """
        r = "redshift"
        const.red = redshift_connector.connect(
             host=config(r, "host"),
             database=config(r, "dbname"),
             user=config(r, 'user'),
             password=config(r, 'password')
        )
        cursor = const.red.cursor()
        cursor.execute(sql)
        res = cursor.fetch_numpy_array()
        L = []
        if len(res):
            SUM = np.sum(res[:,3].astype(int))
            for label_id, collection_id, nft_type, cnt in res:
                L.append({
                    'labelId': label_id,
                    'collectionId': collection_id,
                    'nftType': nft_type,
                    'count': cnt
                 })
        else:
           SUM = 0
        return {'list': L, 'total': SUM}

    async def azuraMoneyflowGroupbyDt(self, request: RequestEntity):
        sql = """
            select amount as sum from gamedb_xzj.public.azura_tongbei_groupby_dt order by ts desc limit 1
        """
        print(sql)
        r = "redshift"
        const.red = redshift_connector.connect(
             host=config(r, "host"),
             database=config(r, "dbname"),
             user=config(r, 'user'),
             password=config(r, 'password')
        )
        cursor = const.red.cursor()
        cursor.execute(sql)
        res = cursor.fetch_numpy_array()
        res = res.tolist()
        if len(res):
            res = res[0][0]

        return {'total': res}


    @Cache.set(cache_time=60*30)
    async def xzj_charge_total_amount(self, request: RequestEntity):
        # 充值流水数据库
        sql = f"""
        with tableorder1 as 
    (
    select * from gamedb_xzj_cbt.oop_payment.hw_order0
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order1
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order2
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order3
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order4
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order5
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order6
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order7
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order8
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order9
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order10
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order11
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order12
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order13
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order14
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order15
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order16
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order17
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order18
    union all
    select * from gamedb_xzj_cbt.oop_payment.hw_order19
    )
,table_orders as
    ( 
    select uid as account_id, serverid as serverid,
    case 
        when paysource = 'MC' then price*0.034 --paysource = 'MC'，则支付货币为新台币
        else price 
    end as total_top_up, to_date(DATEADD(S,CAST(paytime AS BIGINT) - 5*3600 ,'1970-01-01 00:00:00'),'yyyy-mm-dd hh24:mi:ss') as paydate
    from tableorder1 
    where status in ( 2 , 5) -- 0|订单初始化  1|订单完成，还未发货 2|订单完成 3|发货失败 4|订单取消 5|退款 6|无效订单 7|测试订单 -- 对于某一笔订单来说，只存在0123467中的某一个状态
    and serverid in (select gamesvrid from gamedb_xzj."ods"."server_info" where open_to_user = 'yes' and (gamesvrid = 22101 or time_zone = 'UTF-5'))
    and paytime >= 1672930800 -- '2023-01-05 23:00:00' UTC+8 的unix时间戳
    )
select sum(total_top_up) from table_orders
        """
        r = "redshift"
        const.red = redshift_connector.connect(
             host=config(r, "host"),
             database="gamedb_xzj",
             user=config(r, 'user'),
             password=config(r, 'password')
        )
        cursor = const.red.cursor()
        cursor.execute(sql)
        res = cursor.fetch_numpy_array()
        L = []
        SUM = 0
        if len(res):
            SUM = float(res[0][0])
        return {'list': L, 'total': SUM}
