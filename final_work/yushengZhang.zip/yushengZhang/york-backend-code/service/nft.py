# -*- coding:utf-8 -*-
import json
from decimal import *
from elasticsearch.client import IndicesClient

from common.es_conn import EsConn
from core.decorator.cache import Cache
from core.decorator.log import Apm
from core.entity.request import RequestEntity
from core.search.builder import SearchBuilder
from function.function import config, SDEBUG, DEBUG
from models.app import AppModel, AppSearchRequest
from service.base import BaseService
from service.cache import CacheService
from utils.utils import log_exception, index_exception, eslog
from share.repository.els import ElsRepository
from core.const import const
from repository.db import DBRepository


class NftService(BaseService):

    def __init__(self):
        self.es_client = EsConn.instance()
        self.index_client = IndicesClient(self.es_client.conn)

    #@Cache.set(cache_time=60*3)
    async def search(self, request: RequestEntity):
        kw = request.getKeyword()
        fro = request.getFrom()
        limit = request.getLimit()
        label_id_list = request.getLabelIdList()
        priceLow = request.getPriceLow()
        priceHigh = request.getPriceHigh()
        priceRange = [["gte", priceLow], ["lte", priceHigh]] if (priceLow!="" or priceHigh!="") else None
        _sort = request.getSort()
        sort_key = '';
        sort_value = '';
        if _sort:
            sort_key, sort_value = list(_sort[0].keys())[0], list(_sort[0].values())[0]

        sub_dsl = SearchBuilder().match('nft_name_token_id', kw, 100)
        sub_dsl = sub_dsl.term("status", 10)
        if request.getGameId():
            sub_dsl = sub_dsl.term('game_id', request.getGameId())
        if priceRange:
            sub_dsl = sub_dsl.range('unit_price', priceRange)
        if label_id_list:
            sub_dsl = sub_dsl.term("nft_label_ids", label_id_list.split(","))
        if request.getCollectionId():
            sub_dsl = sub_dsl.term("collection_id", request.getCollectionId().split(","))

        builder = (
            SearchBuilder()
           .boolQuery()
           .must(
               sub_dsl.dsl()
            )
        )

        if sort_key and sort_value:
            builder = builder.sort([{sort_key: sort_value}])  

        query_body = builder.limit(0, 0).dsl()
        query_body["aggs"] = {
            "uniques" : {
                "cardinality" : {
                    "field" : "nft_id"
                }
            },
            "unique_sorted_nft_with_price_asc": {
                "terms": {
                  "field": "nft_id",
                  "size": 1000
                },
                "aggs": {
                    "top1": {
                      "top_hits": {
                        "size": 1,
                        "sort": [
                          {
                            "unit_price": {
                              "order": "asc"
                            }
                          }
                        ]
                      }
                    },
                    "ranking_unit_price": {
                        "min": {
                            "field": "unit_price" if not sort_key else sort_key
                        }
                    },
                    "my_bucket_sort": {
                      "bucket_sort": {
                        "sort": [
                          {
                            "ranking_unit_price": {
                              "order": "asc" if not sort_value else sort_value
                            }
                          }
                        ],
                        "size": limit,
                        "from": fro
                      }
                    }
                }
        }
     }

        if DEBUG():
            SDEBUG(type='search', dsl="echo '\n' '" + json.dumps(query_body).replace('"',"#") + "'|sed 's/#/\"/g'")

        response = await const.es.queryByDSL(
            index="t_market_order",
            dsl=query_body,
            preference=request.getSessionId()
        )
        total = response['hits']['total']['value']
        hits = response['aggregations']['unique_sorted_nft_with_price_asc'].get('buckets', [])

        result = []
        for hit in hits:
            data = {}
            _hit = hit['top1']['hits']['hits'][0]['_source']
            data['id'] = _hit['id']
            data['nftId'] = _hit.get('nft_id')
            data['nftName'] = _hit.get('nft_name')
            data['tokenId'] = _hit.get('token_id')
            data['gameId'] = _hit.get('game_id')
            data['gameName'] = _hit.get('game_name')
            data['unitPrice'] = str(int(Decimal(_hit.get('unit_price'))
        * Decimal(1e18)))
            data['basePrice'] = str(int(Decimal(_hit.get('base_price'))
        * Decimal(1e18)))
            data['hash'] = _hit.get('hash')
            data['num'] = _hit.get('num')
            data['coin'] = _hit.get('coin')
            data['coinId'] = _hit.get('coin_id')
            data['nftImage'] = _hit.get('nft_image')
            data['listingTime'] = _hit['listing_time']
            data['expireTime'] = _hit['expire_time']
            result.append(data)

        pageTotal = response['aggregations']['uniques']['value']
        return result, total, pageTotal


    async def hot(self, request: RequestEntity):
        fro = request.getFrom()
        limit = request.getLimit()
        priceLow = request.getPriceLow()
        priceHigh = request.getPriceHigh()
        priceRange = [["gte", priceLow], ["lte", priceHigh]] if (priceLow!="" or priceHigh!="") else None
        _sort = request.getSort()
        attr = request.getAttr()
        sort_key = '';
        sort_value = '';
        if _sort:
            sort_key, sort_value = list(_sort[0].keys())[0], list(_sort[0].values())[0]

        builder = SearchBuilder()


        sub_dsl = builder.term("status", 10)

        if request.getGameId():
            sub_dsl = sub_dsl.term('game_id', request.getGameId())
        if priceRange:
            sub_dsl = sub_dsl.range('standard_unit_price', priceRange)
        if request.getLabelIdList():
            sub_dsl = sub_dsl.term("nft_label_ids", request.getLabelIdList().split(","))
        if request.getCollectionId():
            sub_dsl = sub_dsl.term("collection_id", request.getCollectionId().split(","))
        if request.getChainId():
            sub_dsl = sub_dsl.term("chain_id", request.getChainId().split(","))
        if request.getNftTypeList():
            sub_dsl = sub_dsl.term("nft_type", request.getNftTypeList().split(","))

        if attr:
            for k, v in attr.items():
                if type(v) == str:
                    sub_dsl = sub_dsl.term(f"attr.{k}", v)
                elif type(v) == list:
                    sub_dsl = sub_dsl.range(f"attr.{k}", [["gte",v[0]],["lte",v[1]]])

        builder = (
            SearchBuilder()
           .boolQuery()
           .must(
               sub_dsl.dsl()
            )
        )

        if request.getFlat():
            query_body = builder.limit(fro, limit).dsl()
            if sort_key and sort_value:
                query_body['sort'] = [
                   {
                      sort_key: {
                        "order": sort_value
                      }
                    }
                ]
        else:
            query_body = builder.limit(0, 0).dsl()

        total = await self.getQueryTotalSize(query_body)

        query_body["aggs"] = {
            "uniques" : {
                "cardinality" : {
                    "field" : "nft_id"
                }
            },
            "unique_sorted_nft_with_price_asc": {
                "terms": {
                  "field": "nft_id",
                  "size": 1000
                },
                "aggs": {
                    "top1": {
                      "top_hits": {
                        "size": 1,
                        "sort": [
                          {
                            "standard_unit_price": {
                              "order": "asc"
                            }
                          }
                        ]
                      }
                    },
                    "ranking_unit_price": {
                        "min": {
                            "field": "standard_unit_price" if not sort_key else sort_key
                        }
                    },
                    "my_bucket_sort": {
                      "bucket_sort": {
                        "sort": [
                          {
                            "ranking_unit_price": {
                              "order": "asc" if not sort_value else sort_value
                            }
                          }
                        ],
                        "size": limit,
                        "from": fro
                      }
                    }
                }
        }
     }

        if request.getFlat():
            del query_body["aggs"]

        if DEBUG():
            SDEBUG(type='hot', dsl="echo '\n' '" + json.dumps(query_body).replace('"',"#") + "'|sed 's/#/\"/g'")

        response = await const.es.queryByDSL(
            index="t_market_order",
            dsl=query_body,
            preference=request.getSessionId()
        )
        hits = []
        if request.getFlat():
            pageTotal = total
            hits = response['hits']['hits']
        else:
            pageTotal = response['aggregations']['uniques']['value']
            hits = response['aggregations']['unique_sorted_nft_with_price_asc'].get('buckets', [])

        result = []
        for hit in hits:
            data = {}
            if request.getFlat():
                _hit = hit['_source']
            else:
                _hit = hit['top1']['hits']['hits'][0]['_source']
            data['id'] = _hit['id']
            data['nftId'] = _hit.get('nft_id')
            data['nftName'] = _hit.get('nft_name')
            data['tokenId'] = _hit.get('token_id')
            data['gameId'] = _hit.get('game_id')
            data['gameName'] = _hit.get('game_name')
            data['unitPrice'] = str(int(Decimal(_hit.get('unit_price'))
        * Decimal(1e18)))
            data['basePrice'] = str(int(Decimal(_hit.get('base_price'))
        * Decimal(1e18)))
            data['hash'] = _hit.get('hash')
            data['num'] = _hit.get('num')
            data['coin'] = _hit.get('coin')
            data['coinId'] = _hit.get('coin_id')
            data['nftImage'] = _hit.get('nft_image')
            data['transSerialNo'] = _hit.get('trans_serial_no')
            data['listingTime'] = _hit['listing_time']
            data['expireTime'] = _hit['expire_time']
            data['chainId'] = _hit.get('chain_id')
            data['standardUnitPrice'] = _hit.get('standard_unit_price')
            data['makerRelayerFee'] = _hit.get('maker_relayer_fee')
            data['makerProtocolFee'] = _hit.get('maker_protocol_fee')
            data['takerRelayerFee'] = _hit.get('taker_relayer_fee')
            data['takerProtocolFee'] = _hit.get('taker_protocol_fee')
            data['nftType'] = _hit.get('nft_type')
            result.append(data)

        return result, total, pageTotal


    #@Cache.set(cache_time=60*1)
    async def getQueryTotalSize(self, query_body):
        query_body['aggs'] = {
            "pageSize": {
                "sum": {
                    "field": "num"
                }
            }
        }
        response = await const.es.queryByDSL(
            index="t_market_order",
            dsl=query_body
        )
        total = int(response['aggregations']['pageSize']['value'])
        return total

 
