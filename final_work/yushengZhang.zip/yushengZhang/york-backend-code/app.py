#coding: utf8
import tornado
import os
from tornado import ioloop, httpserver, web
from functools import reduce

from core.const import const
from core.core import CoreDriver
from function.function import config
from handlers._health import _HealthHandler
from handlers.nft_search import NftSearchHandler
from handlers.nft_hot import NftHotHandler
from handlers.requisite import RequisiteHandler
from handlers.grant import GrantHandler
from handlers.log import LogHandler
from handlers.stat_groupby_nft_collection_type_label import StatGroupbyNftCollectionLabelHandler
from handlers.stat_azura_moneyflow_groupby_dt import AzuraMoneyflowGroupbyDt
from handlers.azura_adjust import AzuraAdjustHandler
from handlers.xzj_charge_total_amount import XzjChargeTotalAmount
from handlers.index import IndexHandler
from handlers.get import GetHandler
from handlers.put import PutHandler
from tornado.web import StaticFileHandler

current_path = os.path.dirname(__file__)

print(current_path)

HEALTH = [
    (r'/_health', _HealthHandler),
    (r'/', IndexHandler),
    (r'/get', GetHandler),
    (r'/put', PutHandler),
    (r"/(.*)",StaticFileHandler,{"path":os.path.join(current_path, "york-frontend/build"), "default_filename":"index.html"}),  
]

HANDLERS = {
    'search': [],
    'log': []
}

def router():
    msg = const.BOOT
    if not const.BOOT:
        msg = '默认'
    if const.BOOT == None:
        routes = reduce(lambda a,b:a+b, HANDLERS.values())
    elif const.BOOT == 'log':
        routes = HANDLERS['log']
    elif const.BOOT == 'search':
        routes = HANDLERS['search']
    routes += HEALTH
    print('启动模块:', msg , ' => ' , '  '.join([i[0] for i in routes]))
    return routes


def main():
    CoreDriver()
    is_debug = int(config('sys', 'debug'))
    const.DEBUG = is_debug
    print('<<< DEBUG >>> ', '打开!!!' if is_debug== 1 else '关闭')
    app = tornado.web.Application(
        router(),
        debug=is_debug
    )
    http_server = tornado.httpserver.HTTPServer(app)
    port = 2000
    http_server.listen(port)
    print('监听 {}'.format(port))
    tornado.ioloop.IOLoop.instance().start()


if __name__ == '__main__':
    main()
