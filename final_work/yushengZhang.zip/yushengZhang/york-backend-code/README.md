# data entrance server
Data gate service, support data exchange, complex data query.
